import React from 'react';

export default function NewPirate() {
    const [name, setName] = useState();
    const [imageUrl, setimageUrl] = useState();
    const [Treasure, setTreasure] = useState();
    const [Phrase, setPhrase] = useState();
    const [Position, setPosition] = useState();
    const [Pegleg, setPegLeg] = useState();
    const [Eyepatch, setEyePatch] = useState();
    const [Hookhand, setHookHand] = useState();
    const [hasError, setHasError] = useState(false);
    
    useEffect(() => {
        axios.get('http://localhost:8000/api/pirates')
          .then(response => setPirates(response.data))
          .catch(() => setHasError(true));
      }, []);
    
      return (
        <div>
            {errors.map((err, i) => (
            <p key={i} style={{color: ‘blue’}}>
            {err}
            </p>
            ))}
        <form onSubmit={handleSubmit}>
            <div>
                <label>Pirate Name:</label>
                <input
                name="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                />
            </div>
            <div>
                <label>Image URL:</label>
                    <input
                        name="imageUrl"
                        value={imageUrl}
                        onChange={(e) => setImageUrl(e.target.value)}
                    />
            </div>
            <div>
                Crew position:
                    <select
                        value={position}
                        onChange={(e) => setPosition(e.target.value)}>
                        <option></option>
                        <option>BoatSwain</option>
                        <option>Captain</option>
                        <option>QuarterMaster</option>
                        <option>PowderMonkey</option>
                    </select>
                    </div>
                    <div>
                        # of Treasure Chest:
                        <input
                            name="chest"
                            value={chest}
                            onChange={(e) => setChest(e.target.value)}
                        />
                    </div>
                    <div>
                        <label>Pirate Catch Phrase:</label>
                            <input
                                name="name"
                                value={phrase}
                                onChange={(e) => setPhrase(e.target.value)}
                            />
                        </div>
                            <label>Peg Leg</label>
                                <input
                                    type="checkbox"
                                    checked={leg}
                                    onChange={(e) => SetLeg(e.target.checked)}
                                />

                            <label>Eye Patch</label>
                            <input
                                type="checkbox"
                                checked={patch}
                                onChange={(e) => SetPatch(e.target.checked)}
                            />

                             <label>Hook Hand</label>
                                <input
                                    type="checkbox"
                                    checked={hook}
                                    onChange={(e) => SetHook(e.target.checked)}
                                />
                                <button>Add</button>
        </form>
