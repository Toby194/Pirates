import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function AllPirates() {
    return (
        <div>
            Hello Pirates
        </div>
    )
}
